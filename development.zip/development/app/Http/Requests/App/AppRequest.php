<?php

namespace App\Http\Requests\App;

use App\Http\Requests\BaseRequest;

class AppRequest extends BaseRequest
{
    //
}
