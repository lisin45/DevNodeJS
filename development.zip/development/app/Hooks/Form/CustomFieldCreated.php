<?php


namespace App\Hooks\Form;


use App\Hooks\HookContract;

class CustomFieldCreated extends HookContract
{

    public function handle()
    {

    }
}
