<?php


namespace App\Hooks\User;


use App\Hooks\HookContract;

class AfterUserInvited extends HookContract
{

    public function handle()
    {
        //
    }
}
