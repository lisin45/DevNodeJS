<?php


namespace App\Hooks\Settings;


use App\Helpers\Core\Traits\InstanceCreator;
use App\Hooks\HookContract;

class BeforeNotificationSettingSaved extends HookContract
{
    use InstanceCreator;

    public function handle()
    {
        // TODO: Implement handle() method.
    }
}