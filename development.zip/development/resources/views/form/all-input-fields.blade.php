@extends('layouts.app')

@section('title', trans('default.form_elements'))

@section('contents')
    <all-form-inputs></all-form-inputs>
@endsection
