@extends('layouts.app')

@section('title', trans('default.form_validations'))

@section('contents')
    <form-validation></form-validation>
@endsection
