@extends('layouts.app')

@section('title', trans('default.advance_datatable'))

@section('contents')
    <advance-datatable></advance-datatable>
@endsection