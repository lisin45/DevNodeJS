@extends('layouts.app')

@section('title', trans('default.basic_datatable'))

@section('contents')
    <basic-datatable></basic-datatable>
@endsection
