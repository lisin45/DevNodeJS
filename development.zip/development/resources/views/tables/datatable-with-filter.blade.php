@extends('layouts.app')

@section('title', trans('default.filters_datatable'))

@section('contents')
    <datatable-with-filter></datatable-with-filter>
@endsection
