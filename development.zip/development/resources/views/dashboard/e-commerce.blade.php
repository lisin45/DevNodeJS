@extends('layouts.app')

@section('title', trans('default.e_commerce_dashboard'))

@section('contents')
    <dashboard-ecommerce></dashboard-ecommerce>
@endsection
