@extends('layouts.app')

@section('title', trans('default.academy_dashboard'))

@section('contents')
    <dashboard-academy></dashboard-academy>
@endsection
