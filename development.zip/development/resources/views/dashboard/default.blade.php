@extends('layouts.app')

@section('title', trans('default.default_dashboard'))

@section('contents')
    <dashboard-default></dashboard-default>
@endsection
