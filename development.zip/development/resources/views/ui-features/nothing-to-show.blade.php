@extends('layouts.app')

@section('title', trans('default.nothing_to_show'))

@section('contents')
<nothing-to-show></nothing-to-show>
@endsection

