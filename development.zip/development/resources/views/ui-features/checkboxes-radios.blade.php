@extends('layouts.app')

@section('title', trans('default.checkboxes_and_radios'))

@section('contents')
    <checkboxes-radios></checkboxes-radios>
@endsection
