@extends('layouts.app')

@section('title', trans('default.notes'))

@section('contents')
    <error-notes></error-notes>
@endsection
