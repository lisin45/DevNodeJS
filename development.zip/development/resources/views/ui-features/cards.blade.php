@extends('layouts.app')

@section('title', trans('default.cards'))

@section('contents')
    <cards></cards>
@endsection
