@extends('layouts.app')

@section('title', trans('default.icons'))

@section('contents')
    <icons></icons>
@endsection

