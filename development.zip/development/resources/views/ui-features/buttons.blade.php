@extends('layouts.app')

@section('title', trans('default.buttons'))

@section('contents')
    <buttons></buttons>
@endsection
