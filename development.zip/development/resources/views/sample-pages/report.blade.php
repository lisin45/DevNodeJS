@extends('layouts.app')

@section('title', trans('default.report'))

@section('contents')
    <report></report>
@endsection
